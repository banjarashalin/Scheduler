/**
 * Author: Sonny
 * Contains ajax requests needed for timeslots
 */

